import { useState } from 'react'
import { api } from '../../../api/client'
import { Notice } from './shared'
import { useAction } from './setup'
import { TEMPLATES, rulebook, teamList } from './templates'

const KINDS = [
  { id: 'team_list', title: 'Team list', need: 'Required',
    hint: 'A spreadsheet (CSV or Excel), or paste the list: one team per line with the club in brackets, rows copied from a spreadsheet, or a WhatsApp message. Contact details are removed.' },
  { id: 'rulebook', title: 'Rulebook', need: 'Recommended',
    hint: 'Points, tiebreakers, match length, groups, who goes through, days and pitches. Without it we use common defaults and tell you which.' },
  { id: 'history', title: 'Last year’s results', need: 'Optional',
    hint: 'Winner, runner-up and semi-finalists: used to seed the draw fairly.' },
  { id: 'venue', title: 'Venue and days', need: 'Optional',
    hint: 'Days and playing times, number of pitches — if they aren’t in the rulebook.' },
]

const REMOVED = { email: 'email addresses', phone: 'phone numbers', date: 'dates of birth', address: 'addresses', identity_code: 'ID numbers' }

function redactionText(report) {
  const parts = Object.entries(report ?? {}).filter(([, n]) => n > 0)
    .map(([k, n]) => `${REMOVED[k] ?? k.replaceAll('_', ' ')} (${n})`)
  return parts.length ? `Removed for privacy: ${parts.join(', ')}` : 'No personal data found'
}

/** The backend reads pasted text as one team per line ("Team (Club)"); rows copied from a
 * spreadsheet go as a CSV file instead, so its table reader uses the header row and columns. */
function pasted(kind, text) {
  const lines = text.split(/\r?\n/).filter((l) => l.trim())
  const table = kind === 'team_list' && lines.length > 1 && lines.filter((l) => /[,;\t]/.test(l)).length >= 0.6 * lines.length
  return table ? { file: new File([text], 'teams.csv', { type: 'text/csv' }) } : { text }
}

function KindCard({ kind, files, setupId, locked, onAdded }) {
  const [mode, setMode] = useState('file')
  const [file, setFile] = useState(null)
  const [text, setText] = useState('')
  const action = useAction(() => {}, async () => {})
  const add = (e) => {
    e.preventDefault()
    action.run(async () => {
      await api.addSetupFile(setupId, kind.id, mode === 'file' ? { file } : pasted(kind.id, text))
      setFile(null)
      setText('')
      e.target.reset()
      await onAdded()
      return null
    }, 'Added.')
  }
  return (
    <form className="setup-doc" onSubmit={add}>
      <div className="setup-doc-head">
        <h3>{kind.title}</h3>
        <span className={`pub-status pub-status--${kind.id === 'team_list' ? 'warn' : 'muted'}`}>{kind.need}</span>
      </div>
      <p className="hint">{kind.hint}</p>
      {files.length > 0 && (
        <ul className="setup-files">
          {files.map((f) => (
            <li key={f.id}>
              <span aria-hidden="true">📄</span> {f.mime || 'text'} · {f.characters.toLocaleString()} characters
              <span className="hint"> · {redactionText(f.redaction_report)}</span>
            </li>
          ))}
        </ul>
      )}
      {!locked && (
        <>
          <div className="chip-row" role="group" aria-label={`${kind.title}: file or text`}>
            <button type="button" className={`chip chip--sm${mode === 'file' ? ' is-active' : ''}`} onClick={() => setMode('file')}>Upload a file</button>
            <button type="button" className={`chip chip--sm${mode === 'text' ? ' is-active' : ''}`} onClick={() => setMode('text')}>Paste text</button>
          </div>
          {mode === 'file' ? (
            <input type="file" accept=".csv,.txt,.xlsx,.pdf,.docx,.png,.jpg,.jpeg,text/*,image/*"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
          ) : (
            <label className="field"><span className="visually-hidden">{kind.title}</span>
              <textarea rows={kind.id === 'team_list' ? 6 : 4} value={text} onChange={(e) => setText(e.target.value)}
                placeholder={kind.id === 'team_list' ? 'North Star (North Star SC)\nRiverside United\n… or paste rows from a spreadsheet' : ''} />
            </label>
          )}
          <Notice action={action} />
          <div>
            <button className="btn btn--ghost btn--sm" disabled={action.busy || (mode === 'file' ? !file : !text.trim())}>
              {action.busy ? 'Uploading…' : files.length ? '+ Add another' : '+ Add'}
            </button>
          </div>
        </>
      )}
    </form>
  )
}

/** Ready-made team list and rulebook: one click adds both and reads them. */
function Templates({ setup, action }) {
  const use = (template) => action.run(async () => {
    await api.addSetupFile(setup.id, 'team_list', { text: teamList(template, setup.tournament) })
    await api.addSetupFile(setup.id, 'rulebook', { text: rulebook(template, setup.tournament) })
    return api.extractSetup(setup.id)
  })
  return (
    <section className="setup-doc setup-templates" aria-labelledby="tpl-h">
      <div className="setup-doc-head"><h3 id="tpl-h">Start from a template</h3></div>
      <p className="hint">No documents at hand? Pick a template: we add an example team list and rulebook for your dates and read them. You can change everything on the next steps.</p>
      <ul className="setup-template-list">
        {TEMPLATES.map((t) => (
          <li key={t.id} className="setup-template">
            <strong>{t.title}</strong>
            <span className="hint">{t.text}</span>
            <button type="button" className="btn btn--ghost btn--sm" disabled={action.busy} onClick={() => use(t)}>Use this template</button>
          </li>
        ))}
      </ul>
    </section>
  )
}

/** Step 2: the documents, then the AI reads them into a draft (the engine draws and schedules it). */
export default function DocumentsStep({ setup, reload, onDone }) {
  const action = useAction(onDone, reload)
  const locked = setup.status === 'published'
  const hasTeams = setup.files.some((f) => f.kind === 'team_list')
  const extracted = Boolean(setup.draft)

  const extract = () => action.run(() => api.extractSetup(setup.id))
  const acceptTerms = () => action.run(async () => {
    await api.acceptProcessingTerms(setup.tournament.organisation_id)
    return api.extractSetup(setup.id)
  })

  return (
    <section className="wiz-card setup-docs">
      {!locked && !hasTeams && <Templates setup={setup} action={action} />}
      {KINDS.map((k) => (
        <KindCard key={k.id} kind={k} files={setup.files.filter((f) => f.kind === k.id)} setupId={setup.id} locked={locked}
          onAdded={reload} />
      ))}
      {setup.status === 'failed' && setup.failure_reason && (
        <p className="form-error" role="alert">Reading the documents failed: {setup.failure_reason}</p>
      )}
      {action.code === 'processing_agreement_required' ? (
        <div className="notice" role="alert">
          <span>Your organisation hasn’t accepted the data processing terms yet. They’re needed before we read uploaded documents.</span>
          <button className="btn btn--accent btn--sm" disabled={action.busy} onClick={acceptTerms}>Accept the terms and continue</button>
        </div>
      ) : <Notice action={action} />}
      {!locked && (
        <div className="wiz-nav">
          <span className="hint">
            {hasTeams ? (extracted ? 'Added more? Read the documents again for a new draft.' : 'Ready when you are — this takes a few seconds.')
              : 'Add the team list to continue.'}
          </span>
          <button className="btn btn--accent" disabled={!hasTeams || action.busy} onClick={extract}>
            {action.busy ? <><span className="spinner" /> Reading your documents…</> : extracted ? 'Read the documents again' : 'Set up my tournament →'}
          </button>
        </div>
      )}
    </section>
  )
}
